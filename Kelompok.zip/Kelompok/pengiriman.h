#ifndef PENGIRIMAN_H
#define PENGIRIMAN_H

#include <iostream>
#include <fstream>
#include <string>

#include "keranjang.h" // Menggunakan file header "keranjang.h"

using namespace std;

class Pengiriman {
public:
    Keranjang keranjang; // Instance dari kelas Keranjang
    string nomorpengiriman; // Variabel untuk menyimpan nomorpengiriman
    string jasapengiriman; // Variabel untuk menyimpan jasapengiriman
    long long int biayapengiriman; // Variabel untuk menyimpan biayapengiriman

    void inputdatapengiriman(); // Fungsi untuk memasukkan data pengiriman
    void masukkanDataKePengiriman(const string& kodetransaksi); // Fungsi untuk menyalin data dari keranjang.txt ke pengiriman.txt berdasarkan kodetransaksi
    void masukkanDataKePembeliKePengiriman(); // Fungsi untuk menyalin data dari pembeli.txt ke pengiriman.txt
    void masukkanDatakeranjangkepengiriman(); // Fungsi untuk menyalin data dari keranjang.txt ke pengiriman.txt
    void simpandatapengiriman(); // Fungsi untuk memuat data dari pengiriman.txt
    void tampilkandatapengiriman(); // Fungsi untuk menampilkan data dari pengiriman.txt
    void hapusdatapengiriman(); // Fungsi untuk menghapus pengiriman.txt
};

void Pengiriman::inputdatapengiriman() {
    cout << "\n===================\n";
    cout << "\n==DATA PENGIRIMAN==\n";
    cout << "\n===================\n";
    cout << "\n";
    cin.ignore(); // Mengabaikan karakter tersisa di buffer input
    cout << "Nomor Pengiriman : ";
    getline(cin, nomorpengiriman); // Membaca baris teks dan menyimpannya di dalam nomorpengiriman
    cout << "Jasa Pengiriman  : ";
    getline(cin, jasapengiriman); // Membaca baris teks dan menyimpannya di dalam jasapengiriman
    cout << "Biaya Pengiriman : Rp ";
    cin >> biayapengiriman; // Membaca nilai long long int dan menyimpannya di dalam biayapengiriman
    cin.ignore(); // Mengabaikan karakter newline
    cout << "Kode Transaksi   : ";
    getline(cin, keranjang.kodetransaksi); // Membaca baris teks dan menyimpannya di dalam keranjang.kodetransaksi
    cout << "\n";
    cout << "\n===================\n";
    cout << "\n===TERIMAKASIH=====\n";
    cout << "\n===================\n";
}

void Pengiriman::masukkanDataKePengiriman(const string& kodetransaksi) {
    ifstream fileKeranjang("keranjang.txt"); // Membuka file keranjang.txt untuk dibaca
    ofstream filePengiriman("pengiriman.txt"); // Membuka file pengiriman.txt untuk ditulis

    if (fileKeranjang.is_open() && filePengiriman.is_open()) { // Memeriksa apakah kedua file berhasil dibuka
        string line;
        bool found = false;

        // Menyalin data dari file keranjang.txt ke pengiriman.txt berdasarkan kode transaksi yang diberikan
        while (getline(fileKeranjang, line)) {
            if (line == keranjang.kodetransaksi) {
                found = true;
                filePengiriman << line << endl; // Menyalin baris (kode transaksi) ke pengiriman.txt

                // Menyalin data dari pembeli.txt ke pengiriman.txt
                while (getline(fileKeranjang, line) && !line.empty()) {
                    filePengiriman << line << endl; // Menyalin baris ke pengiriman.txt
                }
                break;
            }
        }

        fileKeranjang.close(); // Menutup file keranjang.txt
        filePengiriman.close(); // Menutup file pengiriman.txt

        if (found) {
            cout << "Data berhasil dimasukkan ke pengiriman.txt." << endl;
        } else {
            cout << "Data dengan kode transaksi " << keranjang.kodetransaksi << " tidak ditemukan." << endl;
        }
    } else {
        cout << "Gagal membuka file." << endl;
    }
}

void Pengiriman::masukkanDataKePembeliKePengiriman() {
    ifstream filePembeli("pembeli.txt"); // Membuka file pembeli.txt untuk dibaca
    ofstream filePengiriman("pengiriman.txt"); // Membuka file pengiriman.txt untuk ditulis

    if (filePembeli.is_open() && filePengiriman.is_open()) { // Memeriksa apakah kedua file berhasil dibuka
        string line;

        // Menyalin data dari pembeli.txt ke pengiriman.txt
        while (getline(filePembeli, line)) {
            filePengiriman << line << endl; // Menyalin baris ke pengiriman.txt
        }

        filePembeli.close(); // Menutup file pembeli.txt
        filePengiriman.close(); // Menutup file pengiriman.txt

        cout << "Data pembeli berhasil dimasukkan ke pengiriman.txt." << endl;
    } else {
        cout << "Gagal membuka file." << endl;
    }
}

void Pengiriman::masukkanDatakeranjangkepengiriman() {
    ifstream fileKeranjang("keranjang.txt"); // Membuka file keranjang.txt untuk dibaca
    ofstream filePengiriman("pengiriman.txt"); // Membuka file pengiriman.txt untuk ditulis

    if (fileKeranjang.is_open() && filePengiriman.is_open()) { // Memeriksa apakah kedua file berhasil dibuka
        string line;

        // Menyalin data dari keranjang.txt ke pengiriman.txt
        while (getline(fileKeranjang, line)) {
            filePengiriman << line << endl; // Menyalin baris ke pengiriman.txt
        }

        fileKeranjang.close(); // Menutup file keranjang.txt
        filePengiriman.close(); // Menutup file pengiriman.txt

        cout << "Data keranjang berhasil dimasukkan ke pengiriman.txt." << endl;
    } else {
        cout << "Gagal membuka file." << endl;
    }
}

void Pengiriman::simpandatapengiriman() {
    ifstream filePengiriman("pengiriman.txt"); // Membuka file pengiriman.txt untuk dibaca

    if (filePengiriman.is_open()) { // Memeriksa apakah file berhasil dibuka
        string line;

        getline(filePengiriman, jasapengiriman); // Membaca baris teks dan menyimpannya di dalam jasapengiriman
        getline(filePengiriman, keranjang.kodetransaksi); // Membaca baris teks dan menyimpannya di dalam keranjang.kodetransaksi
        getline(filePengiriman, keranjang.pembeli.nama); // Membaca baris teks dan menyimpannya di dalam keranjang.pembeli.nama
        getline(filePengiriman, keranjang.pembeli.kota); // Membaca baris teks dan menyimpannya di dalam keranjang.pembeli.kota
        getline(filePengiriman, keranjang.pembeli.alamat); // Membaca baris teks dan menyimpannya di dalam keranjang.pembeli.alamat
        getline(filePengiriman, keranjang.pembeli.kodelaptop); // Membaca baris teks dan menyimpannya di dalam keranjang.pembeli.kodelaptop
        filePengiriman >> keranjang.pembeli.jumlah; // Membaca nilai long long int dan menyimpannya di dalam keranjang.pembeli.jumlah
        filePengiriman >> keranjang.pembeli.totalharga; // Membaca nilai long long int dan menyimpannya di dalam keranjang.pembeli.totalharga

        getline(filePengiriman, line); // Membaca dan mengabaikan karakter newline

        getline(filePengiriman, keranjang.laptop.brand); // Membaca baris teks dan menyimpannya di dalam keranjang.laptop.brand
        getline(filePengiriman, keranjang.laptop.ram); // Membaca baris teks dan menyimpannya di dalam keranjang.laptop.ram
        getline(filePengiriman, keranjang.laptop.layar); // Membaca baris teks dan menyimpannya di dalam keranjang.laptop.layar
        getline(filePengiriman, keranjang.laptop.storage); // Membaca baris teks dan menyimpannya di dalam keranjang.laptop.storage
        filePengiriman >> keranjang.laptop.tahunproduksi; // Membaca nilai long long int dan menyimpannya di dalam keranjang.laptop.tahunproduksi
        filePengiriman >> keranjang.laptop.harga; // Membaca nilai long long int dan menyimpannya di dalam keranjang.laptop.harga

        filePengiriman.close(); // Menutup file pengiriman.txt
        cout << "Data pengiriman berhasil dimuat." << endl;
    } else {
        // File tidak ada, mengatur nilai default atau mengosongkan variabel
        keranjang.pembeli.nama = "-";
        keranjang.pembeli.kota = "-";
        keranjang.pembeli.alamat = "-";
        keranjang.pembeli.kodelaptop = "-";
        keranjang.pembeli.jumlah = 0;
        keranjang.pembeli.totalharga = 0;

        cout << "Data pengiriman tidak ditemukan." << endl;
    }
}

void Pengiriman::tampilkandatapengiriman() {
    ifstream filePengiriman("pengiriman.txt"); // Membuka file pengiriman.txt untuk dibaca

    if (filePengiriman.is_open()) { // Memeriksa apakah file berhasil dibuka
        string line;

        cout << "\nData Pengiriman:\n" << endl;

        // Membaca dan menampilkan semua data dari "pengiriman.txt"
        while (getline(filePengiriman, line)) {
            cout << line << endl; // Menampilkan baris ke konsol
        }

        filePengiriman.close(); // Menutup file pengiriman.txt
    } else {
        cout << "Gagal membuka file.\n" << endl;
    }
}

void Pengiriman::hapusdatapengiriman() {
    if (remove("pengiriman.txt") == 0) { // Menghapus file pengiriman.txt
        cout << "Data pengiriman berhasil dihapus.\n";

        // Mengosongkan variabel yang menyimpan data pengiriman
        nomorpengiriman = "-";
        jasapengiriman = "-";
        biayapengiriman = 0;
        keranjang.kodetransaksi = "-";
        keranjang.pembeli.nama = "-";
        keranjang.pembeli.kota = "-";
        keranjang.pembeli.alamat = "-";
        keranjang.pembeli.kodelaptop = "-";
        keranjang.pembeli.jumlah = 0;
        keranjang.pembeli.totalharga = 0;
    } else {
        cout << "Gagal menghapus data pengiriman.\n";
    }
}

#endif
