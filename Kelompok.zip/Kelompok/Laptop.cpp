#include <iostream>
#include <fstream>
#include <string>

#include "pengiriman.h"

using namespace std;

Laptop laptop; // Objek Laptop
Pembeli pembeli; // Objek Pembeli
Keranjang keranjang; // Objek Keranjang
Pengiriman pengiriman; // Objek Pengiriman

int main() {
    int pilihan_menu_utama;
    int pilihan_laptop;
    int pilihan_pembeli;
    int pilihan_keranjang;
    int pilihan_pengiriman;
    bool kembali_ke_menu_utama = false;

    laptop.loadDataLaptop();    // Memuat data yang sudah tersimpan di data_laptop.txt
    pembeli.loadDataPembeli();  // Memuat data yang sudah tersimpan di pembeli.txt
    pengiriman.simpandatapengiriman(); // Memuat data pengiriman yang sudah tersimpan

    do {
        cout << "\n";
        cout << "===========================\n";
        cout << "====== MENU UTAMA ========\n";
        cout << "===========================\n";
        cout << "\n";
        cout << "1. Daftar Laptop\n";
        cout << "2. Daftar Pembeli\n";
        cout << "3. Keranjang\n";
        cout << "4. Detail Pengiriman\n";
        cout << "5. Keluar\n";

        cout << "\nPilihan: ";
        cin >> pilihan_menu_utama;  // Memilih Menu Utama

        switch (pilihan_menu_utama) {
            case 1: // Daftar List Laptop
                do {
                    cout << "\n";
                    cout << "=============================\n";
                    cout << "======= DAFTAR LAPTOP =======\n";
                    cout << "=============================\n";
                    cout << "\n";
                    cout << "1. Tambahkan Data Laptop\n";
                    cout << "2. Tampilkan Data Laptop\n";
                    cout << "3. Hapus Data Laptop\n";
                    cout << "4. Kembali ke Menu Utama\n";

                    cout << "\nPilihan Merk: ";
                    cin >> pilihan_laptop;

                    switch (pilihan_laptop) {
                        case 1: // Tambahkan Data Laptop
                            laptop.inputlaptop();

                            // Simpan data laptop
                            laptop.simpanDataLaptop();
                            break;
                        case 2: // Tampilkan daftar Laptop
                            laptop.outputlaptop();
                            break;
                        case 3:
                            // Hapus Laptop
                            laptop.hapusDataLaptop();
                            break;
                        case 4: // Kembali ke Menu Utama
                            kembali_ke_menu_utama = true;
                            break;
                        default:
                            cout << "\nPILIHAN MERK TIDAK VALID. SILAHKAN COBA LAGI\n";
                            break;
                    }
                } while (!kembali_ke_menu_utama);
                break;

            case 2: // Daftar List Pembeli
                do {
                    cout << "\n";
                    cout << "===========================\n";
                    cout << "========= PEMBELI =========\n";
                    cout << "===========================\n";
                    cout << "\n";
                    cout << "1. Tambahkan Data Pembeli\n";
                    cout << "2. Tampilkan Data Pembeli\n";
                    cout << "3. Hapus Data Pembeli\n";
                    cout << "4. Kembali ke Menu Utama\n";

                    cout << "\nPilihan: ";
                    cin >> pilihan_pembeli;

                    switch (pilihan_pembeli) {
                        case 1:
                            pembeli.laptop = laptop;
                            pembeli.inputpembeli();

                            pembeli.simpanDataPembeli();
                            break;
                        case 2:
                            pembeli.outputpembeli();
                            break;
                        case 3:
                            pembeli.hapusDataPembeli();
                            break;
                        case 4: // Kembali ke Menu Utama
                            kembali_ke_menu_utama = true;
                            break;
                        default:
                            cout << "\nPILIHAN TIDAK VALID. SILAHKAN COBA LAGI\n";
                            break;
                        }
                    } while (!kembali_ke_menu_utama);
                    break;

            case 3: // Menu Keranjang
                do {
                    cout << "\n";
                    cout << "===========================\n";
                    cout << "========= KERANJANG =========\n";
                    cout << "===========================\n";
                    cout << "\n";
                    cout << "1. Tambahkan Data Keranjang\n";
                    cout << "2. Tampilkan Data Keranjang\n";
                    cout << "3. Hapus Data Keranjang\n";
                    cout << "4. Kembali ke Menu Utama\n";

                    cout << "\nPilihan: ";
                    cin >> pilihan_keranjang;

                    switch (pilihan_keranjang) {
                        case 1:
                            // masukkan kode transaksi
                            keranjang.inputKodeTransaksi();

                            keranjang.masukkanDataKeKeranjang(keranjang.kodetransaksi);
                            keranjang.masukkanDataLaptopKeKeranjang();
                            keranjang.masukkanDataPembeliKeKeranjang();

                            //simpan data
                            keranjang.simpanDataKeranjang();
                            break;
                        case 2:
                            // tampilkan data keranjang
                            keranjang.tampilkanDataKeranjang();
                            break;
                        case 3:
                            // hapus data keranjang
                            keranjang.hapusDataKeranjang();
                            break;
                        case 4:
                            // kembali ke menu utama
                            kembali_ke_menu_utama = true;
                            break;
                        default:
                            cout << "\nPILIHAN TIDAK VALID. SILAHKAN COBA LAGI\n";
                            break;
                    }
                } while (!kembali_ke_menu_utama);
                break;

            case 4: // Menu Pengiriman
                do {
                    cout << "\n";
                    cout << "===========================\n";
                    cout << "======== PENGIRIMAN =======\n";
                    cout << "===========================\n";
                    cout << "\n";
                    cout << "1. Tambahkan Data Pengiriman\n";
                    cout << "2. Tampilkan Data Pengiriman\n";
                    cout << "3. Hapus Data Pengiriman\n";
                    cout << "4. Kembali ke Menu Utama\n";

                    cout << "\nPilihan: ";
                    cin >> pilihan_pengiriman;

                    switch (pilihan_pengiriman) {
                        case 1:
                            // masukkan kode transaksi
                            pengiriman.inputdatapengiriman();
                            pengiriman.masukkanDataKePengiriman(keranjang.pembeli.kodetransaksi);
                            pengiriman.masukkanDataKePembeliKePengiriman();
                            pengiriman.masukkanDatakeranjangkepengiriman();

                            pengiriman.simpandatapengiriman();
                            break;
                        case 2:
                           //
                            pengiriman.tampilkandatapengiriman();
                            break;
                        case 3:
                            // hapus data pengiriman
                            pengiriman.hapusdatapengiriman();
                            break;
                        case 4:
                            // kembali ke menu utama
                            kembali_ke_menu_utama = true;
                            break;
                        default:
                            cout << "\nPILIHAN TIDAK VALID. SILAHKAN COBA LAGI\n";
                            break;
                    }
                } while (!kembali_ke_menu_utama);
                break;
            case 5: // Keluar
                cout << "======== TERIMA KASIH ========\n";
                break;
            default:
                cout << "\nPILIHAN MENU UTAMA TIDAK VALID. SILAHKAN COBA LAGI\n";
                break;
        }
    } while (pilihan_menu_utama != 5);

    return 0;
}
