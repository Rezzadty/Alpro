#ifndef LAPTOP_H
#define LAPTOP_H

#include <iostream>
#include <fstream>
#include <string>


using namespace std;

class Laptop {
public:
    string kodelaptop;
    string brand;
    string layar;
    string ram;
    string storage;
    long long int harga;
    float tahunproduksi;

    void inputlaptop(); // Fungsi untuk memasukkan data laptop
    void outputlaptop(); // Fungsi untuk menampilkan data laptop
    void simpanDataLaptop(); // Fungsi untuk menyimpan data laptop ke dalam file
    void loadDataLaptop(); // Fungsi untuk memuat data laptop dari file
    void hapusDataLaptop(); // Fungsi untuk menghapus data laptop
};

void Laptop::inputlaptop() {
    cout << "\n===================\n";
    cout << "\n===DATA LAPTOP=====\n";
    cout << "\n===================\n";
    cout << "\n";
    cout << "Kode Laptop    : ";
    cin >> kodelaptop; // Membaca input kode laptop
    cout << "Brand Laptop   : ";
    cin >> brand; // Membaca input brand laptop
    cin.ignore();
    cout << "Ram Laptop     : ";
    getline(cin, ram); // Membaca input ram laptop
    cout << "Layar Laptop   : ";
    getline(cin, layar); // Membaca input layar laptop
    cout << "Storage Laptop : ";
    getline(cin, storage); // Membaca input storage laptop
    cout << "Tahun produksi : ";
    cin >> tahunproduksi; // Membaca input tahun produksi
    cout << "Harga Laptop   : Rp ";
    cin >> harga; // Membaca input harga laptop
    cout << "\n";
    cout << "\n===================\n";
    cout << "\n===TERIMAKASIH=====\n";
    cout << "\n===================\n";
}

void Laptop::outputlaptop() {
    cout << "\n===================\n";
    cout << "\n===DATA LAPTOP=====\n";
    cout << "\n===================\n";
    cout << "\n";
    cout << "Kode Laptop    : " << kodelaptop << endl; // Menampilkan kode laptop
    cout << "Brand Laptop   : " << brand << endl; // Menampilkan brand laptop
    cout << "Ram Laptop     : " << ram << endl; // Menampilkan ram laptop
    cout << "Layar Laptop   : " << layar << endl; // Menampilkan layar laptop
    cout << "Storage Laptop : " << storage << endl; // Menampilkan storage laptop
    cout << "Tahun Produksi : " << tahunproduksi << endl; // Menampilkan tahun produksi
    cout << "Harga Laptop   : Rp " << harga << endl; // Menampilkan harga laptop
    cout << "\n";
    cout << "\n===================\n";
}

void Laptop::simpanDataLaptop() {
    ofstream file("data_laptop.txt"); // Membuka file data_laptop.txt untuk ditulis

    if (file.is_open()) { // Memeriksa apakah file berhasil dibuka
        file << kodelaptop << endl; // Menulis kode laptop ke dalam file
        file << brand << endl; // Menulis brand laptop ke dalam file
        file << layar << endl; // Menulis layar laptop ke dalam file
        file << ram << endl; // Menulis ram laptop ke dalam file
        file << storage << endl; // Menulis storage laptop ke dalam file
        file << tahunproduksi << endl; // Menulis tahun produksi ke dalam file
        file << harga << endl; // Menulis harga laptop ke dalam file

        file.close(); // Menutup file
        cout << "Data laptop berhasil disimpan." << endl;
    } else {
        cout << "Gagal membuka file untuk menyimpan data laptop." << endl;
    }
}

void Laptop::loadDataLaptop() {
    ifstream file("data_laptop.txt"); // Membuka file data_laptop.txt untuk dibaca

    if (file.is_open()) { // Memeriksa apakah file berhasil dibuka
        getline(file, kodelaptop); // Membaca baris teks dan menyimpannya di dalam kodelaptop
        getline(file, brand); // Membaca baris teks dan menyimpannya di dalam brand
        getline(file, layar); // Membaca baris teks dan menyimpannya di dalam layar
        getline(file, ram); // Membaca baris teks dan menyimpannya di dalam ram
        getline(file, storage); // Membaca baris teks dan menyimpannya di dalam storage
        file >> tahunproduksi; // Membaca nilai float dan menyimpannya di dalam tahunproduksi
        file >> harga; // Membaca nilai long long int dan menyimpannya di dalam harga

        file.close(); // Menutup file
        cout << "Data laptop berhasil dimuat." << endl;
    } else {
        // File tidak ada, set nilai default atau mengosongkan variabel
        kodelaptop = "-";
        brand = "-";
        layar = "-";
        ram = "-";
        storage = "-";
        tahunproduksi = 0;
        harga = 0;

        cout << "Data laptop tidak ditemukan." << endl;
    }
}

void Laptop::hapusDataLaptop() {
    if (remove("data_laptop.txt") == 0) { // Menghapus file data_laptop.txt
        cout << "Data Laptop berhasil dihapus.\n";

        // Mengosongkan variabel-variabel yang menyimpan data laptop
        kodelaptop = "-";
        brand = "-";
        layar = "-";
        ram = "-";
        storage = "-";
        tahunproduksi = 0;
        harga = 0;
    } else {
        cout << "Gagal menghapus data Laptop.\n";
    }
}

#endif
