#ifndef PEMBELI_H
#define PEMBELI_H

#include <iostream>
#include <fstream>
#include <string>

#include "laptop.h" // Menggunakan file header "laptop.h"

using namespace std;

class Pembeli {
public:
    Laptop laptop; // Instance dari kelas Laptop

    string nama;
    string kota;
    string alamat;
    string kodelaptop;
    string kodetransaksi;
    int jumlah;
    long long int totalharga;

    void inputpembeli(); // Fungsi untuk memasukkan data pembeli
    void outputpembeli(); // Fungsi untuk menampilkan data pembeli
    void simpanDataPembeli(); // Fungsi untuk menyimpan data pembeli ke dalam file
    void loadDataPembeli(); // Fungsi untuk memuat data pembeli dari file
    void hapusDataPembeli(); // Fungsi untuk menghapus data pembeli
};

void Pembeli::inputpembeli() {
    cout << "\n===================\n";
    cout << "\n===DATA PEMBELI====\n";
    cout << "\n===================\n";
    cout << "\n";
    cout << "Nama Pembeli   : ";
    cin.ignore();
    getline(cin, nama); // Membaca input nama pembeli
    cout << "Kota Pembeli   : ";
    getline(cin, kota); // Membaca input kota pembeli
    cout << "Alamat Pembeli : ";
    getline(cin, alamat); // Membaca input alamat pembeli
    cout << "Kode Transaksi : ";
    cin >> kodetransaksi; // Membaca input kode transaksi
    cout << "Kode Laptop    : ";
    cin >> kodelaptop; // Membaca input kode laptop
    cout << "Jumlah Laptop  : ";
    cin >> jumlah; // Membaca input jumlah laptop
    totalharga = laptop.harga * jumlah; // Menghitung total harga berdasarkan harga laptop dan jumlah yang dibeli
    cout << "\n";
    cout << "\n===================\n";
    cout << "\n===TERIMAKASIH=====\n";
    cout << "\n===================\n";
}

void Pembeli::outputpembeli() {
    cout << "\n===================\n";
    cout << "\n===DATA Pembeli====\n";
    cout << "\n===================\n";
    cout << "\n";
    cout << "Nama Pembeli   : " << nama << endl; // Menampilkan nama pembeli
    cout << "Kota Pembeli   : " << kota << endl; // Menampilkan kota pembeli
    cout << "Alamat Pembeli : " << alamat << endl; // Menampilkan alamat pembeli
    cout << "Kode Transaksi : " << kodetransaksi << endl; // Menampilkan kode transaksi
    cout << "Kode Laptop    : " << kodelaptop << endl; // Menampilkan kode laptop
    cout << "Jumlah Laptop  : " << jumlah << endl; // Menampilkan jumlah laptop
    cout << "Total Harga    : " << totalharga << endl; // Menampilkan total harga
    cout << "\n";
    cout << "\n===================\n";
}

void Pembeli::simpanDataPembeli() {
    ofstream file("pembeli.txt"); // Membuka file pembeli.txt untuk ditulis

    if (file.is_open()) { // Memeriksa apakah file berhasil dibuka
        file << nama << endl; // Menulis nama ke dalam file
        file << kota << endl; // Menulis kota ke dalam file
        file << alamat << endl; // Menulis alamat ke dalam file
        file << kodetransaksi << endl; // Menulis kode transaksi ke dalam file
        file << kodelaptop << endl; // Menulis kode laptop ke dalam file
        file << jumlah << endl; // Menulis jumlah laptop ke dalam file
        file << totalharga << endl; // Menulis total harga ke dalam file

        file.close(); // Menutup file
        cout << "Data pembeli berhasil disimpan." << endl;
    } else {
        cout << "Gagal membuka file untuk menyimpan data pembeli." << endl;
    }
}

void Pembeli::loadDataPembeli() {
    ifstream file("pembeli.txt"); // Membuka file pembeli.txt untuk dibaca

    if (file.is_open()) { // Memeriksa apakah file berhasil dibuka
        getline(file, nama); // Membaca baris teks dan menyimpannya di dalam nama
        getline(file, kota); // Membaca baris teks dan menyimpannya di dalam kota
        getline(file, alamat); // Membaca baris teks dan menyimpannya di dalam alamat
        getline(file, kodetransaksi); // Membaca baris teks dan menyimpannya di dalam kodetransaksi
        getline(file, kodelaptop); // Membaca baris teks dan menyimpannya di dalam kodelaptop
        file >> jumlah; // Membaca nilai int dan menyimpannya di dalam jumlah
        file >> totalharga; // Membaca nilai long long int dan menyimpannya di dalam totalharga

        file.close(); // Menutup file
        cout << "Data pembeli berhasil dimuat." << endl;
    } else {
        // File tidak ada, set nilai default atau mengosongkan variabel
        nama = "-";
        kota = "-";
        alamat = "-";
        kodetransaksi = "-";
        kodelaptop = "-";
        jumlah = 0;
        totalharga = 0;

        cout << "Data pembeli tidak ditemukan." << endl;
    }
}

void Pembeli::hapusDataPembeli() {
    if (remove("pembeli.txt") == 0) { // Menghapus file pembeli.txt
        cout << "Data Laptop berhasil dihapus.\n";

        // Mengosongkan variabel-variabel yang menyimpan data laptop
        nama = "-";
        kota = "-";
        alamat = "-";
        kodetransaksi = "-";
        kodelaptop = "-";
        jumlah = 0;
        totalharga = 0;
    } else {
        cout << "Gagal menghapus data Laptop.\n";
    }
}

#endif
