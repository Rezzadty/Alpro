#ifndef KERANJANG_H
#define KERANJANG_H

#include <iostream>
#include <fstream>
#include <string>

#include "pembeli.h" // Menggunakan file header "pembeli.h"
#include "laptop.h" // Menggunakan file header "laptop.h"

using namespace std;

class Keranjang {
public:
    Laptop laptop; // Instance dari kelas Laptop
    Pembeli pembeli; // Instance dari kelas Pembeli
    string kodetransaksi; // Variabel untuk menyimpan kodetransaksi

    void inputKodeTransaksi(); // Fungsi untuk memasukkan kode transaksi
    void masukkanDataKeKeranjang(const string& kodetransaksi); // Fungsi untuk menyalin data dari pembeli.txt ke keranjang.txt berdasarkan kodetransaksi
    void masukkanDataLaptopKeKeranjang(); // Fungsi untuk menyalin data dari data_laptop.txt ke keranjang.txt
    void masukkanDataPembeliKeKeranjang(); // Fungsi untuk menyalin data dari pembeli.txt ke keranjang.txt
    void simpanDataKeranjang(); // Fungsi untuk memuat data dari keranjang.txt
    void tampilkanDataKeranjang(); // Fungsi untuk menampilkan data dari keranjang.txt
    void hapusDataKeranjang(); // Fungsi untuk menghapus keranjang.txt
};

void Keranjang::inputKodeTransaksi() {
    cout << "Masukkan kode transaksi: ";
    cin >> kodetransaksi; // Membaca input kode transaksi dari pengguna
}

void Keranjang::masukkanDataKeKeranjang(const string& kodetransaksi) {
    ifstream filePembeli("pembeli.txt"); // Membuka file pembeli.txt untuk dibaca
    ofstream fileKeranjang("keranjang.txt"); // Membuka file keranjang.txt untuk ditulis

    if (filePembeli.is_open() && fileKeranjang.is_open()) { // Memeriksa apakah kedua file berhasil dibuka
        string line;

        // Menyalin data dari file pembeli.txt ke keranjang.txt berdasarkan kode transaksi yang diberikan
        bool found = false;
        while (getline(filePembeli, line)) {
            if (line == kodetransaksi) {
                found = true;
                fileKeranjang << line << endl; // Menyalin baris (kode transaksi) ke keranjang.txt

                // Menyalin data dari pembeli.txt ke keranjang.txt
                while (getline(filePembeli, line) && !line.empty()) {
                    fileKeranjang << line << endl; // Menyalin baris ke keranjang.txt
                }
                break;
            }
        }

        filePembeli.close(); // Menutup file pembeli.txt
        fileKeranjang.close(); // Menutup file keranjang.txt

        if (found) {
            cout << "\nData berhasil dimasukkan ke keranjang.txt." << endl;
        } else {
            cout << "Data dengan kode transaksi " << kodetransaksi << " tidak ditemukan." << endl;
        }
    } else {
        cout << "Gagal membuka file." << endl;
    }
}

void Keranjang::masukkanDataLaptopKeKeranjang() {
    ifstream fileLaptop("data_laptop.txt"); // Membuka file data_laptop.txt untuk dibaca
    ofstream fileKeranjang("keranjang.txt"); // Membuka file keranjang.txt untuk ditulis

    if (fileLaptop.is_open() && fileKeranjang.is_open()) { // Memeriksa apakah kedua file berhasil dibuka
        string line;

        // Menyalin data dari data_laptop.txt ke keranjang.txt
        while (getline(fileLaptop, line)) {
            fileKeranjang << line << endl; // Menyalin baris ke keranjang.txt
        }

        fileLaptop.close(); // Menutup file data_laptop.txt
        fileKeranjang.close(); // Menutup file keranjang.txt

        cout << "Data laptop berhasil dimasukkan ke keranjang.txt." << endl;
    } else {
        cout << "Gagal membuka file." << endl;
    }
}

void Keranjang::masukkanDataPembeliKeKeranjang() {
    ifstream filePembeli("pembeli.txt"); // Membuka file pembeli.txt untuk dibaca
    ofstream fileKeranjang("keranjang.txt"); // Membuka file keranjang.txt untuk ditulis

    if (filePembeli.is_open() && fileKeranjang.is_open()) { // Memeriksa apakah kedua file berhasil dibuka
        string line;

        // Menyalin data dari pembeli.txt ke keranjang.txt
        while (getline(filePembeli, line)) {
            fileKeranjang << line << endl; // Menyalin baris ke keranjang.txt
        }

        filePembeli.close(); // Menutup file pembeli.txt
        fileKeranjang.close(); // Menutup file keranjang.txt

        cout << "Data pembeli berhasil dimasukkan ke keranjang.txt." << endl;
    } else {
        cout << "Gagal membuka file." << endl;
    }
}


void Keranjang::simpanDataKeranjang() {
    ifstream fileKeranjang("keranjang.txt"); // Membuka file keranjang.txt untuk dibaca

    if (fileKeranjang.is_open()) { // Memeriksa apakah file berhasil dibuka
        string line;

        getline(fileKeranjang, kodetransaksi); // Membaca baris teks dan menyimpannya di dalam kodetransaksi
        getline(fileKeranjang, pembeli.nama); // Membaca baris teks dan menyimpannya di dalam pembeli.nama
        getline(fileKeranjang, pembeli.kota); // Membaca baris teks dan menyimpannya di dalam pembeli.kota
        getline(fileKeranjang, pembeli.alamat); // Membaca baris teks dan menyimpannya di dalam pembeli.alamat
        getline(fileKeranjang, pembeli.kodelaptop); // Membaca baris teks dan menyimpannya di dalam pembeli.kodelaptop
        fileKeranjang >> pembeli.jumlah; // Membaca nilai int dan menyimpannya di dalam pembeli.jumlah
        fileKeranjang >> pembeli.totalharga; // Membaca nilai int dan menyimpannya di dalam pembeli.totalharga
        getline(fileKeranjang, line); // Membaca dan mengabaikan karakter newline

        getline(fileKeranjang, laptop.brand); // Membaca baris teks dan menyimpannya di dalam laptop.brand
        getline(fileKeranjang, laptop.ram); // Membaca baris teks dan menyimpannya di dalam laptop.ram
        getline(fileKeranjang, laptop.layar); // Membaca baris teks dan menyimpannya di dalam laptop.layar
        getline(fileKeranjang, laptop.storage); // Membaca baris teks dan menyimpannya di dalam laptop.storage
        fileKeranjang >> laptop.tahunproduksi; // Membaca nilai int dan menyimpannya di dalam laptop.tahunproduksi
        fileKeranjang >> laptop.harga; // Membaca nilai int dan menyimpannya di dalam laptop.harga

        fileKeranjang.close(); // Menutup file keranjang.txt
        cout << "Data keranjang berhasil dimuat." << endl;
    } else {
        // File tidak ada, mengatur nilai default atau mengosongkan variabel
        pembeli.nama = "-";
        pembeli.kota = "-";
        pembeli.alamat = "-";
        pembeli.kodelaptop = "-";
        pembeli.jumlah = 0;
        pembeli.totalharga = 0;

        cout << "Data keranjang tidak ditemukan." << endl;
    }
}

void Keranjang::tampilkanDataKeranjang() {
    ifstream fileKeranjang("keranjang.txt"); // Membuka file keranjang.txt untuk dibaca

    if (fileKeranjang.is_open()) { // Memeriksa apakah file berhasil dibuka
        string line;

        cout << "\nData Keranjang:\n" << endl;

        // Membaca dan menampilkan semua data dari "keranjang.txt"
        while (getline(fileKeranjang, line)) {
            cout << line << endl; // Menampilkan baris ke layar
        }

        fileKeranjang.close(); // Menutup file keranjang.txt
    } else {
        cout << "Gagal membuka file." << endl;
    }
}

void Keranjang::hapusDataKeranjang() {
    if (remove("keranjang.txt") == 0) { // Menghapus file keranjang.txt
        cout << "Data Keranjang berhasil dihapus.\n";

        // Mengosongkan variabel yang menyimpan data Keranjang
        pembeli.nama = "-";
        pembeli.kota = "-";
        pembeli.alamat = "-";
        pembeli.kodelaptop = "-";
        pembeli.jumlah = 0;
        pembeli.totalharga = 0;
    } else {
        cout << "Gagal menghapus data Keranjang.\n";
    }
}

#endif
